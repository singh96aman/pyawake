<hr style="border-top-width: 4px; border-top-color: #FFFF00;">
<br>
<br>
https://gitlab.cern.ch/AWAKE/pyawake
An open-source library that reads a large number of HDF files and builds a database.API for searching and loading multiple datasets, intelligently identifying dataset dependent parameters, visualize and analyze images to meet the requirements of scientists at AWAKE and port the existing analysis. This project is part of CERN-HSF GSoC project. Author : Aman Singh Thakur, Spencer J Gessner
